import {createBrowserRouter, RouterProvider} from 'react-router-dom'

import Layout from './Pages/Layout/Layout';
import Home from './Pages/Home/Home';
import Products from './Pages/Products/Products';
import Brands from './Pages/Brands/Brands';
import Categories from './Pages/Categories/Categories';
import Cart from './Pages/Cart/Cart';
import Login from './Pages/Login/Login';
import Register from './Pages/Register/Register';
import { Children } from 'react';


function App() {


  const routes = createBrowserRouter([
    { 
      path:'/' , element:<Layout/>, Children:[
        {path:'/', element: <Home/> },
        {path:'/products', element: <Products/>},
        {path:'/brands', element: <Brands/>},
        {path:'/categories', element: <Categories/>},
        {path:'/cart', element: <Cart/>},
        
        
        {path:'/login', element: <Login/>},
        {path:'/register', element: <Register/>},

        

      ]
    }
  ])

  return (
    <>
    <RouterProvider router={routes}/>
    </>
  )
}

export default App
