import React from 'react';

function Categories() {
    return (
        <div>
            Categories
        </div>
    );
}

export default Categories;