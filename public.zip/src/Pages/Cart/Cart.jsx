import React from 'react';

function Cart() {
    return (
        <div>
            cart
        </div>
    );
}

export default Cart;