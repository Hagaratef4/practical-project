import React from 'react';

function Brands() {
    return (
        <div>
            Brands
        </div>
    );
}

export default Brands;